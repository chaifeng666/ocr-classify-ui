4_成果檔：工具與匯出範例
================================
一、工具成品
- ocr.html：本地 OCR 小程式（單檔版，第一次開啟需連網下載程式庫）
- OCR-offline.zip：本地 OCR 小程式離線版（含 Tesseract.js 引擎與繁中／英文語言檔，完全不需連網），解壓後雙擊 start-windows.bat（Mac／Linux 用 start-mac-linux.command）
- OCR-classify-offline.zip：單據分類網頁離線版（簡報 STEP 1～6 示範畫面即此版本），解壓後雙擊 start-windows.bat
- 線上公開版（假資料示範）：https://chaifeng666.github.io/ocr-classify-ui/

二、匯出範例（均為假資料）
- 單據分類_20261024.xlsx：總表＋各類別工作表
- 差旅費交通費明細_20261024.xlsx、帳戶清冊_20261024.xlsx
- A123456001.XML：單據分類網頁匯出的 GBA 受款人 XML
- OCR示範_0310001.XML：3 張假發票 → 2 位受款人、3 筆發票明細（C 組對照）

三、資安證據
- SBOM.xlsx：元件清單，含版本、授權、來源國

四、參考答案.txt：5_題目檔的參考答案（講師用）

注意：Windows 啟動檔尚未在實機測過，上課前請講師先試一次。
